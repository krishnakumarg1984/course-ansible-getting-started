The sample code can be found here:
- https://github.com/g0t4/course-ansible-getting-started